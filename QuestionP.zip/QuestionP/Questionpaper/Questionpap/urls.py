
from django.urls import path

from. import views

urlpatterns = [
    path('',views.log),
    path('index',views.index),

    path('signup',views.signup),
    path('addquestion', views.addquestion),
    path('viewquestion', views.viewquestion),

    path('register', views.register),
    path('login', views.login1),
    path('viewq2', views.viewquestion2),
    path('addq',views.addq),
    path('accept/<int:id>',views.accept),
    path('reject/<int:id>',views.reject),
    path('viewt', views.viewteacher),
    path('edit',views.edit),
    path('edit2',views.edit2),
    path('viewtchr',views.viewtchr),
    path('qgenerate',views.qgenerate),
    path('viewiqac',views.viewiqac),


]