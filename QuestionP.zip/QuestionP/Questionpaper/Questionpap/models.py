from django.db import models

# Create your models here.
class login(models.Model):
    username=models.CharField(max_length=20)
    password=models.CharField(max_length=20)
    type=models.CharField(max_length=20)

class subject(models.Model):
    subname = models.CharField(max_length=20)


class teacher(models.Model):
    firstname=models.CharField(max_length=20)
    lastname=models.CharField(max_length=20)
    mobile=models.BigIntegerField()
    email=models.CharField(max_length=20)
    logid=models.ForeignKey(login,on_delete=models.CASCADE)
    subid = models.ForeignKey(subject, on_delete=models.CASCADE)



class question(models.Model):
    question= models.TextField()
    mark=models.IntegerField()
    status=models.CharField(max_length=20)
    semester = models.IntegerField()
    module = models.IntegerField()
    subid = models.ForeignKey(subject, on_delete=models.CASCADE)
    tid = models.ForeignKey(teacher, on_delete=models.CASCADE)
