from django.shortcuts import render
from django.http import HttpResponse
from .models import *

# Create your views here.
def index(request):
    return render(request,"index.html")

def log(request):
    return render(request,"login.html")
def signup(request):
    return render(request,"signup.html")
def register(request):
    fname = request.POST["firstname"]
    lname = request.POST["lastname"]
    username = request.POST["username"]
    password = request.POST["password"]
    sub = request.POST["subject"]
    email = request.POST["email"]
    phone = request.POST["phone"]
    iqac = request.POST.getlist('iqac')


    logobj = login()
    logobj.username = username
    logobj.password = password
    if len(iqac) == 1:
        logobj.type = "iqac"
    else:
        logobj.type = "teacher"
    logobj.save()

    sub = sub.lower()
    subobj = subject.objects.filter(subname=sub)
    if len(subobj)== 0:
        subobj = subject()
        subobj.subname = sub
        subobj.save()
    else:
        subobj = subobj[0]

    tobj = teacher()
    tobj.firstname = fname
    tobj.lastname = lname
    tobj.email = email
    tobj.mobile = phone
    tobj.logid = logobj
    tobj.subid = subobj
    tobj.save()

    return HttpResponse("<script>alert('Registered');window.location='/'</script>")
def login1(request):
    uname=request.POST['username']
    psword = request.POST['password']

    loglist = login.objects.get(username=uname, password=psword)
    request.session["userid"] = loglist.id
    if(loglist.type == 'iqac'):
        return render(request, "iqac homepage.html")
    elif(loglist.type == 'admin'):
        return render(request, "admin homepage.html")
    else:
        return render(request, "teacher homepage.html")
def addquestion(request):
    sublist = subject.objects.all()
    return render(request,"addquestion.html", {"sub": sublist})

def viewquestion(request):
    return render(request,"viewquestion.html")

def viewquestion2(request):
    tid = request.session.get('userid')
    tobj = teacher.objects.get(logid=tid)

    sid = tobj.subid.id

    queslist = question.objects.filter(subid=sid, status="not approved")
    return render(request,"viewquestion2.html", {"ques": queslist})

def addq(request):
    quest= request.POST['question']
    mark = request.POST['mark']
    sem = request.POST['semester']
    module = request.POST['module']

    tid = request.session.get('userid')
    tobj = teacher.objects.get(logid=tid)

    sid = tobj.subid.id

    sub = subject.objects.get(id=sid)

    addobj = question()
    addobj.question = quest
    addobj.mark = mark
    addobj.semester = sem
    addobj.module = module
    addobj.subid = sub
    addobj.status = "not approved"
    addobj.tid = tobj
    addobj.save()
    return HttpResponse("<script>alert('Question Addedd');window.location='/addquestion'</script>")


def accept(request, id):
    qobj = question.objects.get(id=id)
    qobj.status = "approved"
    qobj.save()
    return HttpResponse("<script>window.location='/viewq2'</script>")

def reject(request, id):
    question.objects.get(id=id).delete()
    return HttpResponse("<script>window.location='/viewq2'</script>")

def viewteacher(request):
    teachlist = teacher.objects.all()
    return render(request,"viewteacher.html",{"teach": teachlist})

def edit(request):
    return render(request,'Viewandedit.html')

def edit2(request):
    return render(request,'edit2.html')



def viewtchr(request):
    return render(request, 'viewtchr.html')

def qgenerate(request):
    return render(request,'qgenerate.html')

def viewiqac(request):
    return render(request,'viewiqac.html')


